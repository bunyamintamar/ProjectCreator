
#!/bin/bash
aplay /opt/playSuccess/success.wav

