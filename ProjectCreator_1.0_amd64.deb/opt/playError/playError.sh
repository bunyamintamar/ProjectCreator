
#!/bin/bash
aplay /opt/playError/error.wav

